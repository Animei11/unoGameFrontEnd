const img = document.createElement("img");
img.src = "https://i.pinimg.com/originals/3c/08/53/3c0853e08afd33d0698a665616abf538.png";
document.body.appendChild(img);
